import { app, BrowserWindow, desktopCapturer, safeStorage, session as electronSession, shell } from "electron"
import fs from "node:fs"
import path from "node:path"
import { openOwnKeyForm, registerIpc } from "./ipc"
import { Logger, type LogLevel } from "./services/logger"
import { captureScreen } from "./services/capture"
import { ChatService } from "./services/chat"
import { SimulationService } from "./services/simulation"
import { LocalAsrSocket } from "./services/localAsr"
import { ProjectKnowledgeService } from "./services/projectKnowledgeService"
import { CloudSync } from "./services/cloud"
import { Llm } from "./services/llm"
import { MeetingStore } from "./services/meetings"
import { ReportGenerator } from "./services/reports"
import { RecordingSession } from "./services/session"
import { AsrModel } from "./services/asrModel"
import { RefineModels } from "./services/refine"
import { SettingsStore } from "./services/settings"
import { TranscriptAutosave } from "./services/transcriptFiles"
import { setLocale } from "../shared/i18n"
import { autoAnswerAllowed, getLanguage } from "../shared/types"
import { SuggestionService } from "./services/suggestions"
import { PlanService } from "./services/plan"
import { OwnKeyService } from "./services/ownKey"
import { keychainBox, sealLegacyOwnKey } from "./services/secretBox"
import { ShortcutManager } from "./shortcuts"
import { createTray } from "./tray"
import { WindowManager } from "./windows/WindowManager"
import { runRefineSmoke, runSmokeTest } from "./smoke"
import { startAutoUpdates } from "./updater"

// Smoke runs use their own profile so they neither collide with a running install
// (single-instance lock) nor touch its settings and meetings.
if (process.env.IGPT_SMOKE) app.setPath("userData", path.join(app.getPath("temp"), "igpt-smoke"))

if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  bootstrap()
}

function bootstrap(): void {
  app.commandLine.appendSwitch("disable-background-timer-throttling")
  process.on("uncaughtException", (err) => console.error("[main] uncaught:", err))
  process.on("unhandledRejection", (reason) => console.error("[main] unhandled rejection:", reason))


  const userData = app.getPath("userData")
  const logger = new Logger(path.join(userData, "logs", "meetingly.log"), (process.env.IGPT_LOG_LEVEL as LogLevel) || "info")
  captureConsole(logger)
  logger.info("app", "starting", { version: app.getVersion(), platform: process.platform, electron: process.versions.electron, packaged: app.isPackaged })

  const settings = new SettingsStore(path.join(userData, "settings.json"), {
    version: app.getVersion(),
    platform: process.platform,
    // Smoke runs can render another interface language (IGPT_SMOKE_LOCALE=ru) to check that the labels fit.
    locale: (process.env.IGPT_SMOKE && process.env.IGPT_SMOKE_LOCALE) || app.getLocale()
  })
  setLocale(settings.uiLocale())
  const box = keychainBox(safeStorage)
  const llm = new Llm(settings, undefined, box)
  const meetings = new MeetingStore(path.join(userData, "meetings.json"))
  const reports = new ReportGenerator({ llm, meetings, settings })
  const modelDir = process.env.MEETINGLY_MODEL_DIR || path.join(userData, "models")
  const asrModel = new AsrModel(modelDir)
  // The second pass: a more accurate model writes each finished utterance again (refine.ts).
  const refineModels = new RefineModels(modelDir)
  // Cloud transcription is part of Unlimited; every other plan transcribes on this computer.
  // Each session is also a .txt in Documents/Meetingly (a temp folder for smoke runs): readable without an account.
  const transcriptDir = process.env.IGPT_SMOKE ? path.join(userData, "transcripts") : path.join(app.getPath("documents"), "Meetingly")
  let lastTranscript: string | null = null
  // While listening, the transcript so far is saved every minute into the file Finish completes.
  const autosave = new TranscriptAutosave(transcriptDir, () => session.draft())
  const openTranscripts = () => {
    fs.mkdirSync(transcriptDir, { recursive: true })
    void shell.openPath(transcriptDir)
  }
  // After Finish without an account: the file manager opens with the new .txt selected.
  const transcripts = {
    reveal: () => (lastTranscript && fs.existsSync(lastTranscript) ? shell.showItemInFolder(lastTranscript) : openTranscripts())
  }
  const session = new RecordingSession({
    settings,
    meetings,
    reports,
    asrModel,
    refine: (language) => refineModels.forLanguage(language),
    cloudTranscription: () => plan.getState().plan === "unlimited",
    onFinished: (meeting) => {
      try {
        lastTranscript = autosave.finish(meeting)
        logger.info("session", `transcript saved to ${lastTranscript}`)
      } catch (err) {
        logger.warn("session", `could not save the transcript file: ${(err as Error).message}`)
      }
    },
    // Discard keeps nothing, including the minute-by-minute copy.
    onDiscarded: () => autosave.discard()
  })
  setInterval(() => {
    try {
      autosave.save()
    } catch (err) {
      logger.warn("session", `could not save the transcript so far: ${(err as Error).message}`)
    }
  }, 60_000)
  const windows = new WindowManager(path.join(__dirname, "preload.js"))
  const projectKnowledge = new ProjectKnowledgeService({ settings })
  projectKnowledge.on("state", (state) => windows.broadcast("projects:changed", state))
  const chat = new ChatService({
    settings,
    llm,
    session,
    capture: captureScreen,
    projectContext: (query) => projectKnowledge.context(query),
    hideForCapture: () => windows.hideForCapture(),
    canAutoAnswer: () => autoAnswerAllowed(plan.getState())
  })
  const suggestions = new SuggestionService({ settings, llm, session, chat })

  let simulation: SimulationService
  const simulationChat = new ChatService({
    settings,
    llm,
    session: {
      transcriptText: () => simulation.transcriptText(),
      getLastUtterance: () => simulation.getLastUtterance()
    },
    capture: captureScreen,
    projectContext: (query) => projectKnowledge.context(query),
    systemInstruction: "This is a practice interview. Input is labeled Interviewer or Candidate. Help the candidate answer the current interviewer question, using candidate statements only as confirmed conversation context. Do not invent personal experience or generate the next interviewer question."
  })
  simulation = new SimulationService({
    settings,
    chat: simulationChat,
    createSocket: () => new LocalAsrSocket({
      language: getLanguage(settings.get().audioLanguage).asr,
      model: asrModel,
      refine: refineModels.forLanguage(settings.get().audioLanguage)
    }),
    canListen: () => session.state().status === "idle"
  })

  const cloud = new CloudSync({
    settings,
    meetings,
    appVersion: app.getVersion(),
    // Smoke runs must never pop a browser on the desktop.
    openExternal: process.env.IGPT_SMOKE ? async () => {} : (url) => shell.openExternal(url),
    cloudUrl: process.env.IGPT_CLOUD_URL || undefined
  })
  const shortcuts = new ShortcutManager({ settings, windows, session, chat, openWeb: () => void cloud.openWeb() })
  cloud.on("state", (s) => logger.info("cloud", `status ${s.status}`, { email: s.email, error: s.error }))
  const plan = new PlanService({ settings })
  simulationChat.on("message", (message) => {
    if (message.role === "assistant" && message.kind !== "error") plan.refreshSoon()
  })
  const ownKey = new OwnKeyService({ settings, box })
  plan.on("state", (s) => logger.info("plan", `${s.status} ${s.plan ?? ""}`, { answers: s.used?.answers, limit: s.limits?.answers }))

  let lastShortcuts = JSON.stringify(settings.get().shortcuts)
  const applySettings = () => {
    const s = settings.get()
    setLocale(settings.uiLocale())
    windows.setStealth(s.stealth)
    if (app.isPackaged) app.setLoginItemSettings({ openAtLogin: s.autoLaunch })
    const serialized = JSON.stringify(s.shortcuts)
    if (serialized !== lastShortcuts) {
      lastShortcuts = serialized
      shortcuts.register()
    }
  }

  app.whenReady().then(() => {
    // The second pass, end to end on recordings: no windows, nothing on screen (smoke.ts).
    if (process.env.IGPT_SMOKE === "refine") return void runRefineSmoke({ asrModel, refineModels })
    try {
      sealLegacyOwnKey(settings, box)
    } catch {
      logger.warn("settings", "The existing API key needs an available OS keychain; the saved setting was retained.")
    }
    if (process.platform === "darwin") app.dock?.hide()
    installSystemAudioHandler()
    registerIpc({ settings, projectKnowledge, simulation, windows, session, chat, suggestions, meetings, reports, logger, cloud, plan, ownKey, transcripts })
    instrument({ logger, settings, session, chat, windows })
    applySettings()
    settings.onChange(applySettings)
    // A new meeting language applies at once, mid-session too.
    settings.onChange(() => session.syncEngine())
    // A meeting left mid-report by a crash or a quit would sit on "processing" forever.
    void reports.resumeUnfinished()
    // Reconnect to the linked account, if any. Never blocks startup.
    void cloud.start().catch((err) => logger.warn("cloud", "start failed", err))
    if (!process.env.IGPT_SMOKE) plan.start()
    windows.createMain()
    createTray(windows, settings, {
      openWeb: (page) => void cloud.openWeb(page),
      openLogs: () => shell.showItemInFolder(logger.file),
      openTranscripts,
      ownKey: () => openOwnKeyForm(windows)
    })
    shortcuts.register()
    if (!process.env.IGPT_SMOKE) {
      startAutoUpdates({
        logger,
        isBusy: () => session.state().status !== "idle",
        onState: (state) => windows.broadcast("update:state", state)
      })
    }
    // The meeting language's second-pass model comes after the live one (which the first Listen needs), and again
    // whenever the meeting language changes.
    const prefetchRefine = () => {
      const s = settings.get()
      // Cloud transcription is Unlimited only: on any other plan the session runs on this computer anyway.
      const onDevice = s.transcriptionEngine === "local" || s.keepMeetingsLocal || plan.getState().plan !== "unlimited"
      if (onDevice && asrModel.isReady() && !process.env.IGPT_SMOKE) refineModels.prefetch(s.audioLanguage)
    }
    settings.onChange(prefetchRefine)
    // Fetch the on-device speech model in the background so the first Listen does not wait for it.
    if (settings.get().transcriptionEngine === "local" && !asrModel.isReady() && !process.env.IGPT_SMOKE) {
      let last = -10
      asrModel.on("progress", (p: number) => {
        if (p >= last + 10) {
          last = p
          logger.info("asr", `model download ${p}%`)
        }
      })
      void asrModel.ensure().then(
        () => {
          logger.info("asr", "model ready")
          prefetchRefine()
        },
        (err) => logger.warn("asr", "model download failed", err)
      )
    } else {
      prefetchRefine()
    }

    // MEETINGLY_AUTOSTART=listen opens the live transcript and starts recording once the windows are up
    // (manual testing; the user stops it from the toolbar).
    if (process.env.MEETINGLY_AUTOSTART === "listen" && !process.env.IGPT_SMOKE) {
      setTimeout(() => {
        windows.showPanel("transcript")
        session.start().then(
          () => logger.info("app", "autostart: recording"),
          (err) => logger.warn("app", "autostart failed", err)
        )
      }, 2500)
    }
    if (process.env.IGPT_SMOKE) void runSmokeTest(process.env.IGPT_SMOKE, { windows, chat, session, settings, cloud, meetings, asrModel })
  })

  app.on("second-instance", () => windows.centerMain())
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) windows.createMain()
    else windows.centerMain()
  })
  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit()
  })
  app.on("will-quit", () => {
    logger.info("app", "quitting")
    void simulation.setListening(false).catch((error) => logger.warn("simulation", "Microphone shutdown failed", error))
    shortcuts.unregister()
    // Quitting mid-session saves it like Finish: the meeting and its .txt now, the report on the next start
    // (reports.resumeUnfinished). Smoke runs end with a quit and must leave nothing behind.
    if (process.env.IGPT_SMOKE) session.cancel()
    else void session.finish()
  })
}

/** Everything already written with console.* lands in the log file too. */
function captureConsole(logger: Logger): void {
  const scopeOf = (args: unknown[]): { scope: string; message: string } => {
    const first = typeof args[0] === "string" ? args[0] : ""
    const match = first.match(/^\[([a-z-]+)\]\s*(.*)$/i)
    const rest = args.slice(1).map((a) => (a instanceof Error ? `${a.name}: ${a.message}` : typeof a === "string" ? a : safeJson(a)))
    if (match) return { scope: match[1], message: [match[2], ...rest].filter(Boolean).join(" ") }
    return { scope: "main", message: [first || safeJson(args[0]), ...rest].filter(Boolean).join(" ") }
  }
  for (const level of ["log", "info", "warn", "error"] as const) {
    const original = console[level].bind(console)
    console[level] = (...args: unknown[]) => {
      const { scope, message } = scopeOf(args)
      logger[level === "log" ? "info" : level](scope, message)
      original(...args)
    }
  }
}

interface InstrumentDeps {
  logger: Logger
  settings: SettingsStore
  session: RecordingSession
  chat: ChatService
  windows: WindowManager
}

/** Log the lifecycle events that matter when diagnosing a session afterwards. */
function instrument({ logger, settings, session, chat, windows }: InstrumentDeps): void {
  let lastStatus = ""
  session.on("state", (state) => {
    if (state.status === lastStatus) return
    lastStatus = state.status
    logger.info("session", `status ${state.status}`, {
      connected: state.connected,
      source: state.audioSource,
      device: state.audioDeviceId || "default",
      notice: state.notice
    })
  })
  session.on("utterance", (u) => logger.info("session", "utterance", { speaker: u.speaker, chars: u.text.length }))
  chat.on("message", (m) => logger.info("chat", `${m.role}/${m.kind}`, { chars: m.text.length }))
  chat.on("busy", (busy) => logger.debug("chat", `busy ${busy}`))
  settings.onChange((s) =>
    logger.info("settings", "changed", {
      source: s.audioSource,
      device: s.audioDeviceId || "default",
      autoAnswer: s.autoAnswer,
      answerLength: s.answerLength,
      audioLanguage: s.audioLanguage,
      outputLanguage: s.outputLanguage,
      stealth: s.stealth
    })
  )

  // Renderer console output (audio capture warnings live there) goes to the same file.
  const attach = (kind: string, contents: Electron.WebContents) => {
    contents.on("console-message", (event) => {
      const line = `${event.message} (${path.basename(event.sourceId)}:${event.lineNumber})`
      if (event.level === "error") logger.error(`renderer:${kind}`, line)
      else if (event.level === "warning") logger.warn(`renderer:${kind}`, line)
      else if (/\[(audio|session|chat)\]/.test(event.message)) logger.info(`renderer:${kind}`, event.message)
    })
    contents.on("render-process-gone", (_e, details) => logger.error(`renderer:${kind}`, "process gone", details))
  }
  windows.on("created", (kind: string, contents: Electron.WebContents) => attach(kind, contents))
}

function safeJson(value: unknown): string {
  try {
    return JSON.stringify(value) ?? String(value)
  } catch {
    return String(value)
  }
}

/**
 * Answers the renderer's getDisplayMedia({audio: true}) with system audio, without
 * showing a picker. The "video" half is the requesting window's own frame: we never
 * use the video, and a screen source would go through Windows Graphics Capture,
 * which refuses elevated processes and exclusive-fullscreen sessions (E_ACCESSDENIED).
 * Windows: Chromium loopback. macOS 13+: CoreAudio tap (needs the
 * NSAudioCaptureUsageDescription plist key, set in package.json build.mac.extendInfo).
 * Linux: no loopback here; the renderer uses PulseAudio monitor devices instead.
 */
function installSystemAudioHandler(): void {
  electronSession.defaultSession.setDisplayMediaRequestHandler(
    (request, callback) => {
      const frame = request.frame && !request.frame.isDestroyed?.() ? request.frame : null
      if (frame) {
        callback({ video: frame, audio: "loopback" })
        return
      }
      desktopCapturer
        .getSources({ types: ["screen"], thumbnailSize: { width: 1, height: 1 } })
        .then((sources) => callback(sources.length ? { video: sources[0], audio: "loopback" } : {}))
        .catch((err) => {
          console.warn("[audio] display media request failed:", err)
          callback({})
        })
    },
    { useSystemPicker: false }
  )
}
